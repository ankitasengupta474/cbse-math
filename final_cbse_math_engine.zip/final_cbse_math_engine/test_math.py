
import sys
import os

# Ensure local package path
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from math_engine import handle_math_query

queries = [
    "Prove that root 7 is irrational",
    "Find the HCF and LCM of 72 and 120 using Euclid’s algorithm"
]

for query in queries:
    print(f"🔍 Query: {query}")
    response = handle_math_query(query)
    print(f"🧠 Response:\n{response}")
    print("="*80)
