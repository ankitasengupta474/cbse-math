
from logic_mapper import detect
from narrator_llm import explain_math_proof
from proof_generator import prove_irrationality, solve_hcf_lcm

def handle_math_query(query: str) -> str:
    info = detect(query)
    logic = info["logic"]
    if logic == "irrationality":
        steps = prove_irrationality(query)
    elif logic == "hcf_lcm":
        steps = solve_hcf_lcm(query)
    else:
        return "Unsupported logic type."
    return explain_math_proof(logic, steps)
