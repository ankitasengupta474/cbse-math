
from .irrationality import prove as prove_irrationality
from .hcf_lcm import solve as solve_hcf_lcm
