
import re
from math import gcd

def parse_numbers(query):
    nums = list(map(int, re.findall(r'\d+', query)))
    return nums[:2] if len(nums) >= 2 else []

def solve(query):
    steps = []
    nums = parse_numbers(query)
    if len(nums) != 2:
        return ["Please provide exactly two numbers for HCF/LCM computation."]

    a, b = nums
    steps.append(f"Step 1: Let the two numbers be {a} and {b}.")
    steps.append("Step 2: Apply Euclid’s Division Lemma: a = bq + r")
    x, y = max(a, b), min(a, b)
    while y:
        steps.append(f"→ {x} = {y} * ({x // y}) + {x % y}")
        x, y = y, x % y
    steps.append(f"Step 3: HCF is {x}")
    lcm = a * b // x
    steps.append(f"Step 4: LCM = (a × b) / HCF = ({a} × {b}) / {x} = {lcm}")
    steps.append(f"✅ Final Answer: HCF = {x}, LCM = {lcm}")
    return steps
