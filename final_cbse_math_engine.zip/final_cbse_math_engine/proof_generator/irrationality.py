
import re

def prove(query: str):
    match = re.search(r'\d+', query)
    if not match:
        return ["Unable to detect number under root."]
    n = int(match.group())
    return [
        f"Step 1: Assume √{n} is rational.",
        f"Step 2: Then √{n} = a/b, where a and b are coprime integers.",
        f"Step 3: Squaring both sides: {n} = a²/b² → a² = {n}b²",
        f"Step 4: Hence, a² divisible by {n} ⇒ a divisible by {n} ⇒ a = {n}c",
        f"Step 5: Substituting: ({n}c)² = {n}b² → b² = {n}c²",
        f"Step 6: So b is also divisible by {n} ⇒ contradiction.",
        f"Conclusion: √{n} is irrational."
    ]
